import React from 'react';
import './App.css';
import Header from './Components/Header';
import Main from './Components/Main';
import Navigation from './Components/Navigation';
import SubContents from './Components/SubContents';
import Advertisement from './Components/Advertisement';
import SomeOtherComponent from './Components/SomeOtherComponent';

function App() {
  return (
    <div className="App">
      <SomeOtherComponent/>
      {/* <Header/>
      <div className='Bottom'>
        <Navigation/>
        <Main>
        </Main>
          
      </div> */}
      


    </div>
  );
}

export default App;
